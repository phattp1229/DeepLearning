# finetuned-gpt2-convai
This repo is about finetuning gpt2 model provided by Transformers. I fine tuned the model in convai dataset.

To learn about this code you can follow this tutorial : https://youtu.be/elUCn_TFdQc
